const express = require('express');
const Stripe = require('stripe');
const stripe = Stripe('sk_test_51QIS2kFa8CBaQoM9eLP6lvpv1RIpRth6J5DWmQjhTxXTWoL4o5FDhVhglY67sxFOmH06BVviK6bRaRl4I18BBf0S00G2RKCPhE'); // Replace with your Stripe secret key
const app = express();

app.use(express.json());

app.post('/create-payment-intent', async (req, res) => {
    const { amount } = req.body;
    try {
        const paymentIntent = await stripe.paymentIntents.create({
            amount,
            currency: 'usd'
        });
        res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.listen(3000, () => console.log('Server running on port 3000'));
