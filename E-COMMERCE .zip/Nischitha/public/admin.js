document.addEventListener("DOMContentLoaded", () => {
    fetchPlants();
    fetchOrders(); // Fetch orders on page load
});

// Fetch and display plants
function fetchPlants() {
    fetch('/plants')
        .then(response => response.json())
        .then(plants => {
            const plantList = document.getElementById('plant-list');
            plantList.innerHTML = '';
            plants.forEach(plant => {
                const plantDiv = document.createElement('div');
                plantDiv.innerHTML = `
                    <h3>${plant.name}</h3>
                    <img src="${plant.imageUrl}" alt="${plant.name}" />
                    <p>Price: $${plant.price}</p>
                    <button onclick="deletePlant('${plant._id}')">Delete</button>
                `;
                plantList.appendChild(plantDiv);
            });
        });
}

// Delete a plant
function deletePlant(plantId) {
    fetch(`/plants/${plantId}`, { method: 'DELETE' })
        .then(response => {
            if (response.ok) {
                alert('Product deleted successfully!');
                fetchPlants(); // Refresh plant list
            } else {
                alert('Error deleting Product: ' + response.statusText);
            }
        })
        .catch(error => alert('Fetch error: ' + error.message));
}

// Add a new plant
document.getElementById('add-plant-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission

    const name = document.getElementById('plant-name').value;
    const imageUrl = document.getElementById('plant-image').value;
    // const description = document.getElementById('plant-description').value;
    const price = document.getElementById('plant-price').value;

    fetch('/plants', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, imageUrl, price }),
    })
    .then(response => {
        if (response.ok) {
            alert('Product added successfully!');
            fetchPlants(); // Refresh plant list
            document.getElementById('add-plant-form').reset(); // Reset the form
        } else {
            alert('Error adding Product.');
        }
    });
});

// Fetch and display orders
function fetchOrders() {
    fetch('/orders')
        .then(response => response.json())
        .then(orders => {
            const orderList = document.getElementById('order-list');
            orderList.innerHTML = '';
            orders.forEach(order => {
                const orderDiv = document.createElement('div');
                orderDiv.innerHTML = `
                    <p><b>Order ID:</b> ${order._id}</p>
                    <p><b>Username:</b> ${order.userId ? order.userId.username : 'Unknown'}</p>
                    <p><b>Productname:</b> ${order.plantId ? order.plantId.name : 'Unknown'}</p>
                    <p><b>Status: <span id="status-${order._id}">${order.status}</span></b></p>
                    <button onclick="updateOrderStatus('${order._id}', 'Shipped')">Ship Order</button>
                    <button onclick="updateOrderStatus('${order._id}', 'Delivered')">Deliver Order</button>
                `;
                orderList.appendChild(orderDiv);
            });
        })
        .catch(error => console.error('Error fetching orders:', error));
}

// Update order status
function updateOrderStatus(orderId, status) {
    fetch(`/orders/${orderId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }), // Only update the status
    })
    .then(response => {
        if (response.ok) {
            document.getElementById(`status-${orderId}`).innerText = status; // Update status display
            alert(`Order status updated to ${status}`);
        } else {
            alert('Error updating order status.');
        }
    });
}
