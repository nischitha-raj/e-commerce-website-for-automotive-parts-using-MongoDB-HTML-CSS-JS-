document.addEventListener("DOMContentLoaded", () => {
    fetchPlants();
    checkUserSession();

    const searchInput = document.getElementById('search');
    searchInput.addEventListener('input', () => {
        const query = searchInput.value;
        fetchPlants(query);
    });

    const logoutButton = document.getElementById('logout');
    logoutButton.addEventListener('click', logout);

    const viewOrdersButton = document.getElementById('view-orders');
    viewOrdersButton.addEventListener('click', toggleOrderList);

    const viewCartButton = document.getElementById('view-cart');
    viewCartButton.addEventListener('click', toggleCartDetails);
});

let cart = [];
let isUserLoggedIn = false;

function fetchPlants(query = '') {
    fetch('/plants')
        .then(response => response.json())
        .then(plants => {
            const plantList = document.getElementById('plant-list');
            plantList.innerHTML = '';
            plants.filter(plant => plant.name.toLowerCase().includes(query.toLowerCase())).forEach(plant => {
                const plantDiv = document.createElement('div');
                plantDiv.innerHTML = `
                    <h3>${plant.name}</h3>
                    <img src="${plant.imageUrl}" alt="${plant.name}" style="width: 230px; height: 150px;" />
                    <h4>Price: $${plant.price}</h4>
                    <button onclick="orderPlant('${plant._id}')">Order</button>
                    ${isUserLoggedIn ? `<button onclick="addToCart('${plant._id}', '${plant.name}', '${plant.imageUrl}', ${plant.price})">Add to Cart</button>` : ''}
                `;
                plantList.appendChild(plantDiv);
            });
        })
        .catch(err => console.error('Error fetching plants:', err));
}

function addToCart(plantId, plantName, imageUrl, price) {
    const existingItem = cart.find(item => item.plantId === plantId);
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({ plantId, plantName, imageUrl, price, quantity: 1 });
    }
    alert(`${plantName} has been added to your cart!`);
    document.getElementById('view-cart').style.display = 'inline';
}

function removeFromCart(plantId) {
    cart = cart.filter(item => item.plantId !== plantId);
    displayCartItems();
    alert('Item removed from the cart');
}

function toggleCartDetails() {
    const cartDetails = document.getElementById('cart-details');
    cartDetails.style.display = cartDetails.style.display === 'none' ? 'block' : 'none';
    if (cartDetails.style.display === 'block') {
        displayCartItems();
    }
}

function displayCartItems() {
    const cartItemsDiv = document.getElementById('cart-items');
    cartItemsDiv.innerHTML = '';
    if (cart.length === 0) {
        cartItemsDiv.innerHTML = '<p>Your cart is empty.</p>';
    } else {
        let totalPrice = 0;
        cart.forEach(item => {
            const itemDiv = document.createElement('div');
            itemDiv.innerHTML = `
                <img src="${item.imageUrl}" alt="${item.plantName}" style="width: 50px; height: 50px;" />
                <p>${item.plantName}</p>
                <p>Price: $${item.price}</p>
                <p>Quantity: ${item.quantity}</p>
                <button onclick="removeFromCart('${item.plantId}')">Remove</button>
                <button onclick="orderPlant('${item.plantId}', ${item.quantity})">Buy</button>
            `;
            cartItemsDiv.appendChild(itemDiv);
            totalPrice += item.price * item.quantity;
        });
        document.getElementById('cart-total').innerText = `Total: $${totalPrice.toFixed(2)}`;
    }
}

function orderPlant(plantId, quantity = 1) {
    if (!isUserLoggedIn) {
        alert('Please log in to place an order.');
        return;
    }

    fetch('/order', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ plantId, quantity }), // Use the quantity passed in
    })
    .then(response => {
        if (response.ok) {
            alert('Order placed successfully!');
            // Optionally, you might want to clear the cart or update the order list
            displayCartItems(); // Update the cart display
        } else {
            alert('Failed to place order. Please try again.');
        }
    })
    .catch(err => {
        console.error('Error placing order:', err);
        alert('Error placing order. Please try again later.');
    });
}

function checkUserSession() {
    fetch('/session')
        .then(response => {
            if (response.ok) {
                isUserLoggedIn = true;
                document.getElementById('logout').style.display = 'inline';
                document.getElementById('view-orders').style.display = 'inline';
                document.getElementById('view-cart').style.display = 'inline';
                fetchPlants(); // Re-fetch plants to display "Add to Cart" button
            }
        })
        .catch(err => console.error('Error checking user session:', err));
}

function logout() {
    fetch('/logout', { method: 'POST' })
        .then(response => {
            if (response.ok) {
                alert('Logged out successfully');
                isUserLoggedIn = false;
                window.location.reload();
            }
        })
        .catch(err => console.error('Error logging out:', err));
}

function toggleOrderList() {
    const orderList = document.getElementById('order-list');
    orderList.style.display = orderList.style.display === 'none' ? 'block' : 'none';
    if (orderList.style.display === 'block') {
        fetchOrders();
    }
}

function fetchOrders() {
    fetch('/orders')
        .then(response => response.json())
        .then(orders => {
            const ordersDiv = document.getElementById('orders');
            ordersDiv.innerHTML = '';
            if (orders.length === 0) {
                ordersDiv.innerHTML = '<p>No orders found.</p>';
            } else {
                orders.forEach(order => {
                    const orderDiv = document.createElement('div');
                    orderDiv.innerHTML = `
                        <p>Order ID: ${order._id}</p>
                        <p>Product: ${order.plantId ? order.plantId.name : 'Unknown'}</p>
                        <p>Status: ${order.status}</p>
                        <p>Date: ${new Date(order.date).toLocaleDateString()}</p>
                        <p>Quantity: ${order.quantity}</p>
                        <p>Total Price: $${order.totalPrice}</p>
                    `;
                    ordersDiv.appendChild(orderDiv);
                });
            }
        })
        .catch(err => {
            console.error('Error fetching orders:', err);
            const ordersDiv = document.getElementById('orders');
            ordersDiv.innerHTML = '<p>Error fetching orders. Please try again later.</p>';
        });
}
