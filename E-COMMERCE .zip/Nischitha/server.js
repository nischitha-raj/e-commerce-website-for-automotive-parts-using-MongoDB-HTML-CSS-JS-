const express = require('express');
const Stripe = require('stripe');
require('dotenv').config();

const stripe = Stripe(process.env.STRIPE_SECRET_KEY);
const app = express();
app.use(express.json());
app.use(express.static('public')); // Serve static files from 'public' folder

// Endpoint to create a payment intent
app.post('/create-payment-intent', async (req, res) => {
    const { amount } = req.body; // Expect amount in the smallest currency unit (e.g., cents)

    try {
        const paymentIntent = await stripe.paymentIntents.create({
            amount,
            currency: 'rupees', // Change as needed
            payment_method_types: ['card'],
        });

        res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
