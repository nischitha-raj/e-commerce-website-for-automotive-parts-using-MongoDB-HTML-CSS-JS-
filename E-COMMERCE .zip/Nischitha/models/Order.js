const mongoose = require('mongoose');

const OrderSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    plantId: { type: mongoose.Schema.Types.ObjectId, ref: 'Plant', required: true },
    status: { type: String, default: 'Pending' },
    date: { type: Date, default: Date.now },
    quantity: { type: Number, default: 1 },
    totalPrice: { type: Number },
    careTips: { type: String } // Field for care tips
});

// Middleware to calculate total price before saving
OrderSchema.pre('save', async function(next) {
    const plant = await this.model('Plant').findById(this.plantId);
    if (plant) {
        this.totalPrice = plant.price * this.quantity;
    }
    next();
});



const Order = mongoose.model('Order', OrderSchema);
module.exports = Order;